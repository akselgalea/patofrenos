function deployModal(event) {
    let btn = event.currentTarget.children[0];
    btn.className = "btn-cerrar-active";
    event.currentTarget.className = "modal-trabajo";
    //event.currentTarget.setAttribute("onClick", "closeModal(event)");
    btn.addEventListener("click", closeModalBtn);
}


function closeModalBtn(btn) {
    let boton = btn.currentTarget;
    boton.className = "btn-cerrar";
    boton.parentElement.setAttribute("class", "trabajo");
    event.stopPropagation();
    boton.parentElement.setAttribute("onClick", "deployModal(event)");
}
