<?php
    require '../partials/database.php';

    $id = $_GET['id'];
    $name = $_GET['name'];
    $query = "DELETE FROM trabajo WHERE id = ". $id;

    $conn->query($query);

    unlink("../src/img-trabajos/" . $name);

    header('Location: /frenos');
 ?>
