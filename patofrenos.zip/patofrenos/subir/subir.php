<?php
    require '../partials/header.php';
    require '../partials/database.php';
    require '../partials/selectAllQuery.php';
?>

    <div id="trabajos" class="container-fluid">
        <div class="container">
            <form class="form-subir" action="subirArchivo.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="fileToUpload" id="fileLabel">Seleccione una imagen para subir</label>
                    <input type="file" name="fileToUpload" id="fileToUpload">
                </div>
                <div class="form-group">
                    <label for="nombre" style="display: block">Ingrese texto a mostrar</label>
                    <input type="text" name="nombre" placeholder="Ingrese texto">
                </div>

                <p class="text-center"><button type="submit" name="submit">Subir imagen</button><p>
            </form>
        </div>
        <h1 class="text-center gfont tds">Trabajos de esta semana</h1>
        <div class="container trabajos-container">
            <?php if(isset($trabajos)) {
                foreach ($trabajos as $t){
            ?>
                <div class="trabajoSubir">
                    <a class="borrar" href="delete.php?id=<?= $t['id']?>&name=<?= $t['foto'] ?>"><svg height="20pt" viewBox="0 0 512 512" width="20pt" xmlns="http://www.w3.org/2000/svg"><path d="m256 512c-141.160156 0-256-114.839844-256-256s114.839844-256 256-256 256 114.839844 256 256-114.839844 256-256 256zm0-475.429688c-120.992188 0-219.429688 98.4375-219.429688 219.429688s98.4375 219.429688 219.429688 219.429688 219.429688-98.4375 219.429688-219.429688-98.4375-219.429688-219.429688-219.429688zm0 0"/><path d="m347.429688 365.714844c-4.679688 0-9.359376-1.785156-12.929688-5.359375l-182.855469-182.855469c-7.144531-7.144531-7.144531-18.714844 0-25.855469 7.140625-7.140625 18.714844-7.144531 25.855469 0l182.855469 182.855469c7.144531 7.144531 7.144531 18.714844 0 25.855469-3.570313 3.574219-8.246094 5.359375-12.925781 5.359375zm0 0"/><path d="m164.570312 365.714844c-4.679687 0-9.355468-1.785156-12.925781-5.359375-7.144531-7.140625-7.144531-18.714844 0-25.855469l182.855469-182.855469c7.144531-7.144531 18.714844-7.144531 25.855469 0 7.140625 7.140625 7.144531 18.714844 0 25.855469l-182.855469 182.855469c-3.570312 3.574219-8.25 5.359375-12.929688 5.359375zm0 0"/></svg></a>
                    <img class="trabajo-img" src="../src/img-trabajos/<?= $t['foto'] ?>" alt="">
                    <p>
                        <?php if(! empty($t['nombre'])) {
                            echo $t['nombre'];
                        } else echo $t['fecha_subida'];
                        ?>
                    </p>
                </div>
            <?php }
        } else echo "<h1>No hay imagenes para mostrar</h1>" ?>
        </div>
    </div>

    <script type="text/javascript">
        document.getElementById("fileToUpload").addEventListener("change", archivoSelec);

        function archivoSelec() {
            texto = event.currentTarget.value.substr(12);
            event.currentTarget.previousElementSibling.innerHTML = texto;
        }
    </script>
<?php include '../partials/footer.php'; ?>
