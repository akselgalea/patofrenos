<?php
    require '../partials/database.php';

    echo $_FILES["fileToUpload"]["name"].'<br>';
    $target_dir = "../src/img-trabajos/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    // Check if image file is a actual image or fake image
    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }

    if (file_exists($target_file)) {
        echo "El archivo que estas tratando de subir ya existe.";
        $uploadOk = 0;
    }

        // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "<br>El archivo no ha sido subido. Sera redireccionado dentro de 3 segundos";
        header( "refresh:3;url=/frenos" );
    } else { // if everything is ok, try to upload file
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo $querySubir = "INSERT INTO trabajo (nombre, foto) VALUES ('". $_POST['nombre']. "', '". $_FILES['fileToUpload']['name']. "');";
            $conn->query($querySubir);

            header('Location: /frenos');
        } else {
            echo "Lo sentimos, hubo un error subiendo el archivo.";
            header( "refresh:3;url=/frenos" );
        }
    }
