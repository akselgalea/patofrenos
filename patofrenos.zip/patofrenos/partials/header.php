<?php
    include_once 'getinfo.php';
?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
    <head>
        <!-- Desarrollado por Axel Ormeño @akuseryuinc-->
        <meta charset="utf-8">
        <title><?= $data->nombre ?></title>
        <link rel="stylesheet" href="/css/main.css">
        <link rel="shortcut icon" href="/src/favicon.png">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Russo+One&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    </head>
    <body>
        <div class="container-fluid presentacion-container">
            <div class="presentacion">
                <div class="logo">
                    <?php  if(substr($_SERVER['REQUEST_URI'], 0, 6) == '/subir') { ?>
                            <a href="/"><img src="../src/logo.png" alt="logo patofrenos" /></a>
                    <?php } else { ?>
                            <a href="/"><img src="src/logo.png" alt="logo patofrenos" /></a>
                    <?php } ?>
                </div>
                <div>
                    <p id="tituloPatofrenos" class="gfont">Servicio de frenos para autos y camiones a domicilio</p>
                </div>
            </div>
        </div>
