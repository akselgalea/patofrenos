        <div class="footer">
            <footer><p>© 2020 <?= $data->nombre ?> - Servicio de frenos y venta de pastillas | Desarrollado por <b><a href="https://www.instagram.com/akuseryuinc" target="_blank">@akuseryuinc</a><b></p>
        </div>
    </body>
</html>
