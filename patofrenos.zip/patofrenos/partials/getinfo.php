<?php

    $json = file_get_contents("https://raw.githubusercontent.com/akuseryuinc/patofrenos/main/datos.json?token=AIZX2QKIP6EZCCPF3UYHYKS72Q4R2");
    $data = json_decode($json);
