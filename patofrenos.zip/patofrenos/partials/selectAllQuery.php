<?php
    $selectAllQuery = "SELECT * FROM trabajo ORDER BY fecha_subida DESC";
    $trabajos = $conn->query($selectAllQuery);
 ?>
