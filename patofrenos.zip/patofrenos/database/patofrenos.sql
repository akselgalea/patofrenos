-- Creating the database
CREATE DATABASE patofrenos;

-- Using the database
use patofrenos;

-- Creating the tables
CREATE TABLE trabajo (
  id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50),
  foto VARCHAR(50),
  fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- To show all tables
SHOW TABLES;

-- To describe all tables
describe trabajo;
