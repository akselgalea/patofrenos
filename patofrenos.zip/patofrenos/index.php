<?php
    require 'partials/header.php';
    require 'partials/database.php';
    require 'partials/selectAllQuery.php';
 ?>

<div class="container-fluid contacto-section">
    <div class="container contacto-container">
        <div class="contacto-web">
            <form class="contacto-form" method="post" action="sendmail.php">
                <h3>CONTÁCTANOS VÍA WEB</h3>
                <div class="contacto-item">
                    <input type="text" name="nombre" placeholder="Nombre completo" value="" title="Ingrese su nombre" required>
                </div>
                <div class="contacto-item">
                    <input type="text" name="celular" placeholder="Celular" value="" title="Ingrese su numero de telefono" required>
                </div>
                <div class="contacto-item">
                    <input type="text" name="email" placeholder="Email" value="" title="Ingrese su correo" required>
                </div>
                <div class="contacto-item">
                    <input type="date" name="fecha" placeholder="Agenda aquí" value="" title="Ingrese la fecha en la que quiere el servicio" required>
                </div>

                <h3>Que necesitas?</h3>
                <div class="contacto-item cbox">
                    <input id="frenos-auto" type="checkbox" name="necesito[]" value="Frenos auto ">
                    <label for="frenos-auto"><span>&nbsp;Frenos auto</span></label>
                </div>
                <div class="contacto-item cbox">
                    <input id="frenos-camion" type="checkbox" name="necesito[]" value="Pastillas auto ">
                    <label for="frenos-camion"><span>&nbsp;Pastillas auto</span></label>
                </div>
                <div class="contacto-item cbox">
                    <input id="pastillas-auto" type="checkbox" name="necesito[]" value="Frenos camion ">
                    <label for="pastillas-auto"><span>&nbsp;Frenos camion</span></label>
                </div>
                <div class="contacto-item cbox">
                    <input id="pastillas-camion" type="checkbox" name="necesito[]" value="Pastillas camion ">
                    <label for="pastillas-camion"><span>&nbsp;Pastillas camion</span></label>
                </div>
                <div class="contacto-item cbox">
                    <button type="submit" class="enviar">Enviar</button>
                </div>
            </form>
        </div>
        <div class="contacto-redes">
            <h3>Otras formas de contacto</h3>
            <a href="<?= $data->facebook ?>" target="_blank"><svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
            	 viewBox="0 0 512 512" width="1.5rem" height="1.5rem" style="enable-background:new 0 0 512 512;" xml:space="preserve">
            <path style="fill:#1976D2;" d="M448,0H64C28.704,0,0,28.704,0,64v384c0,35.296,28.704,64,64,64h384c35.296,0,64-28.704,64-64V64
            	C512,28.704,483.296,0,448,0z"/>
            <path style="fill:#FAFAFA;" d="M432,256h-80v-64c0-17.664,14.336-16,32-16h32V96h-64l0,0c-53.024,0-96,42.976-96,96v64h-64v80h64
            	v176h96V336h48L432,256z"/>
            </svg> Facebook</a>
            <a href="<?= $data->instagram ?>" target="_blank"><svg enable-background="new 0 0 24 24" height="1.5rem" viewBox="0 0 24 24" width="1.5rem" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><linearGradient id="SVGID_1_" gradientTransform="matrix(0 -1.982 -1.844 0 -132.522 -51.077)" gradientUnits="userSpaceOnUse" x1="-37.106" x2="-26.555" y1="-72.705" y2="-84.047"><stop offset="0" stop-color="#fd5"/><stop offset=".5" stop-color="#ff543e"/><stop offset="1" stop-color="#c837ab"/></linearGradient><path d="m1.5 1.633c-1.886 1.959-1.5 4.04-1.5 10.362 0 5.25-.916 10.513 3.878 11.752 1.497.385 14.761.385 16.256-.002 1.996-.515 3.62-2.134 3.842-4.957.031-.394.031-13.185-.001-13.587-.236-3.007-2.087-4.74-4.526-5.091-.559-.081-.671-.105-3.539-.11-10.173.005-12.403-.448-14.41 1.633z" fill="url(#SVGID_1_)"/><path d="m11.998 3.139c-3.631 0-7.079-.323-8.396 3.057-.544 1.396-.465 3.209-.465 5.805 0 2.278-.073 4.419.465 5.804 1.314 3.382 4.79 3.058 8.394 3.058 3.477 0 7.062.362 8.395-3.058.545-1.41.465-3.196.465-5.804 0-3.462.191-5.697-1.488-7.375-1.7-1.7-3.999-1.487-7.374-1.487zm-.794 1.597c7.574-.012 8.538-.854 8.006 10.843-.189 4.137-3.339 3.683-7.211 3.683-7.06 0-7.263-.202-7.263-7.265 0-7.145.56-7.257 6.468-7.263zm5.524 1.471c-.587 0-1.063.476-1.063 1.063s.476 1.063 1.063 1.063 1.063-.476 1.063-1.063-.476-1.063-1.063-1.063zm-4.73 1.243c-2.513 0-4.55 2.038-4.55 4.551s2.037 4.55 4.55 4.55 4.549-2.037 4.549-4.55-2.036-4.551-4.549-4.551zm0 1.597c3.905 0 3.91 5.908 0 5.908-3.904 0-3.91-5.908 0-5.908z" fill="#fff"/></svg> Instagram</a>
            <a href="https://wa.me/<?= $data->whatsapp ?>" target="_blank"><svg height="1.5rem" viewBox="-1 0 512 512" width="1.5rem" xmlns="http://www.w3.org/2000/svg"><path d="m10.894531 512c-2.875 0-5.671875-1.136719-7.746093-3.234375-2.734376-2.765625-3.789063-6.78125-2.761719-10.535156l33.285156-121.546875c-20.722656-37.472656-31.648437-79.863282-31.632813-122.894532.058594-139.941406 113.941407-253.789062 253.871094-253.789062 67.871094.0273438 131.644532 26.464844 179.578125 74.433594 47.925781 47.972656 74.308594 111.742187 74.289063 179.558594-.0625 139.945312-113.945313 253.800781-253.867188 253.800781 0 0-.105468 0-.109375 0-40.871093-.015625-81.390625-9.976563-117.46875-28.84375l-124.675781 32.695312c-.914062.238281-1.84375.355469-2.761719.355469zm0 0" fill="#e5e5e5"/><path d="m10.894531 501.105469 34.46875-125.871094c-21.261719-36.839844-32.445312-78.628906-32.429687-121.441406.054687-133.933594 109.046875-242.898438 242.976562-242.898438 64.992188.027344 125.996094 25.324219 171.871094 71.238281 45.871094 45.914063 71.125 106.945313 71.101562 171.855469-.058593 133.929688-109.066406 242.910157-242.972656 242.910157-.007812 0 .003906 0 0 0h-.105468c-40.664063-.015626-80.617188-10.214844-116.105469-29.570313zm134.769531-77.75 7.378907 4.371093c31 18.398438 66.542969 28.128907 102.789062 28.148438h.078125c111.304688 0 201.898438-90.578125 201.945313-201.902344.019531-53.949218-20.964844-104.679687-59.09375-142.839844-38.132813-38.160156-88.832031-59.1875-142.777344-59.210937-111.394531 0-201.984375 90.566406-202.027344 201.886719-.015625 38.148437 10.65625 75.296875 30.875 107.445312l4.804688 7.640625-20.40625 74.5zm0 0" fill="#fff"/><path d="m19.34375 492.625 33.277344-121.519531c-20.53125-35.5625-31.324219-75.910157-31.3125-117.234375.050781-129.296875 105.273437-234.488282 234.558594-234.488282 62.75.027344 121.644531 24.449219 165.921874 68.773438 44.289063 44.324219 68.664063 103.242188 68.640626 165.898438-.054688 129.300781-105.28125 234.503906-234.550782 234.503906-.011718 0 .003906 0 0 0h-.105468c-39.253907-.015625-77.828126-9.867188-112.085938-28.539063zm0 0" fill="#64b161"/><g fill="#fff"><path d="m10.894531 501.105469 34.46875-125.871094c-21.261719-36.839844-32.445312-78.628906-32.429687-121.441406.054687-133.933594 109.046875-242.898438 242.976562-242.898438 64.992188.027344 125.996094 25.324219 171.871094 71.238281 45.871094 45.914063 71.125 106.945313 71.101562 171.855469-.058593 133.929688-109.066406 242.910157-242.972656 242.910157-.007812 0 .003906 0 0 0h-.105468c-40.664063-.015626-80.617188-10.214844-116.105469-29.570313zm134.769531-77.75 7.378907 4.371093c31 18.398438 66.542969 28.128907 102.789062 28.148438h.078125c111.304688 0 201.898438-90.578125 201.945313-201.902344.019531-53.949218-20.964844-104.679687-59.09375-142.839844-38.132813-38.160156-88.832031-59.1875-142.777344-59.210937-111.394531 0-201.984375 90.566406-202.027344 201.886719-.015625 38.148437 10.65625 75.296875 30.875 107.445312l4.804688 7.640625-20.40625 74.5zm0 0"/><path d="m195.183594 152.246094c-4.546875-10.109375-9.335938-10.3125-13.664063-10.488282-3.539062-.152343-7.589843-.144531-11.632812-.144531-4.046875 0-10.625 1.523438-16.1875 7.597657-5.566407 6.074218-21.253907 20.761718-21.253907 50.632812 0 29.875 21.757813 58.738281 24.792969 62.792969 3.035157 4.050781 42 67.308593 103.707031 91.644531 51.285157 20.226562 61.71875 16.203125 72.851563 15.191406 11.132813-1.011718 35.917969-14.6875 40.976563-28.863281 5.0625-14.175781 5.0625-26.324219 3.542968-28.867187-1.519531-2.527344-5.566406-4.046876-11.636718-7.082032-6.070313-3.035156-35.917969-17.726562-41.484376-19.75-5.566406-2.027344-9.613281-3.035156-13.660156 3.042969-4.050781 6.070313-15.675781 19.742187-19.21875 23.789063-3.542968 4.058593-7.085937 4.566406-13.15625 1.527343-6.070312-3.042969-25.625-9.449219-48.820312-30.132812-18.046875-16.089844-30.234375-35.964844-33.777344-42.042969-3.539062-6.070312-.058594-9.070312 2.667969-12.386719 4.910156-5.972656 13.148437-16.710937 15.171875-20.757812 2.023437-4.054688 1.011718-7.597657-.503906-10.636719-1.519532-3.035156-13.320313-33.058594-18.714844-45.066406zm0 0" fill-rule="evenodd"/></g></svg> Whatsapp</a>

            <h3 class="mt-3">Ver trabajos de esta semana</h3>
            <p class="text-center">
                <a href="#trabajos" class="ver-mas">
                    <svg id="flechaAbajo" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                	 width="3rem" height="3rem" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
                        <g>
                        	<path d="M20,0C8.973,0,0,8.973,0,20c0,11.027,8.973,20,20,20c11.027,0,20-8.973,20-20C40,8.973,31.027,0,20,0z M27.756,23.465
                        		l-6.279,5.332C21.051,29.158,20.525,29.34,20,29.34c-0.526,0-1.052-0.182-1.478-0.543l-6.279-5.332
                        		c-0.959-0.816-1.077-2.256-0.262-3.217c0.815-0.959,2.255-1.078,3.216-0.262l2.521,2.141v-9.186c0-1.26,1.021-2.281,2.282-2.281
                        		c1.26,0,2.281,1.021,2.281,2.281v9.186l2.521-2.141c0.962-0.814,2.401-0.697,3.218,0.262
                        		C28.834,21.209,28.716,22.648,27.756,23.465z"/>
                        </g>
                    </svg>
                </a>
            </p>
        </div>
    </div>
</div>
<div id="trabajos" class="container-fluid">
    <h1 class="text-center gfont tds">Trabajos de esta semana</h1>
    <div class="trabajos-container">
        <?php if($trabajos) {
            foreach ($trabajos as $t){
        ?>
            <div class="trabajo" onclick="deployModal(event)">
                <span class="btn-cerrar" onclick="closeModalBtn(event)">X</span>
                <img class="trabajo-img" src="src/img-trabajos/<?= $t['foto'] ?>" alt="" title="<?= $t['fecha_subida'] ?>">
                <p>
                    <?php if(! empty($t['nombre'])) {
                        echo $t['nombre'];
                    } else echo $t['fecha_subida'];
                    ?>
                </p>
            </div>
        <?php }
    } else echo "<h1>No hay imagenes para mostrar</h1>" ?>
    </div>
</div>

<script type="text/javascript" src="js/modal-trabajo.js"></script>
<?php include 'partials/footer.php'; ?>
